import random
import pdb
from Cartas import Carta,Mazo,ManoIA,Mano,ManoPersona


class ListaJugadores:


    def __init__(self):
        self.jugadores  = []
        self.numJug = 0
        self.turno = 0

    def pasar_turno(self):
        self.turno += 1
        if self.turno == self.numJug:
            self.turno = 0
        
    def imprimir_nombre(self,idx):
        self.jugadores[idx].imprimirNombre()
        
    def inicializar_partida(self,n_jugadores=2):
        self.numJug = n_jugadores
        #el primer jugador siempre sera la maquina
        self.jugadores.append(JugadorIA('Ordenador'))
        for idxJug in range(1,self.numJug+1):
            nombreJugador = input("Cual es el nombre del  jugador {0}?".format(idxJug))
            self.jugadores.append(JugadorPersona(nombreJugador))

        
    def jugar_primera_ronda(self):
        self.jugadores[0].imprimir_nombre()
        self.jugadores[0].imprimir()
        print("Se pasa a ELIMINAR LAS PAREJAS")
        contOut = self.jugadores[0].eliminar_parejas()
        print('Se han eliminado {0}'.format(contOut))
        print("Ahora las cartas son: ")
        self.jugadores[0].imprimir()
        ##################
        #TODO anadir el loop que recorra los jugadores y elimine de sus manos las parejas
        ##################
        #
        # Colocar el for aqu�
        #
        
    def inicializar_turno(self):
        self.turno = random.randrange(0,self.numJug)
        
    def jugar_ronda(self):
        print("Las cartas del jugador actual son: ")
        self.jugadores[self.turno].imprimir()

        seguir = True
        idxJugActual=self.turno
        if idxJugActual == 0:#es el Ordenador el que juega
            print("El Ordenador elige jugador: ")
        else:
            print("El jugador {0} elige jugador: ".format(idxJugActual))
            for idx in range(0,self.numJug+1):
                if idx != idxJugActual:
                    print("El jugador con idx {0} es ".format(idx))
                    self.jugadores[idx].imprimir_nombre()

        idxSelec = self.jugadores[self.turno].solicitar_a_que_jugador(idxJugActual,self.numJug)
        cartaRobada = self.jugadores[idxSelec].solicitar_carta_al_jugadorX(self.jugadores[idxSelec].cuantas_cartas_quedan())
        self.jugadores[idxSelec].eliminar_carta(cartaRobada)
        self.jugadores[self.turno].anadir_carta(cartaRobada)
        seguir = self.jugadores[idxSelec].tiene_cartas()
        
        contOut = self.jugadores[self.turno].eliminar_parejas()
        print('Se han eliminado {0}'.format(contOut))
        self.jugadores[self.turno].imprimir()
        return seguir,idxSelec
        
    def repartir_cartas(self, baraja):
        i=0
        #baraja.barajar()
        mona = baraja.apartar_mona()           # coger la carta de la cima y seleccionarla como mona eliminandola del mazo. Esto tiene como consecuencia que a quien le toque la complementaria de la mona, no podra emparejarla y perdera la partida
        num_cartas = baraja.cuantas_cartas_quedan()
        
        while i <= num_cartas and not baraja.esta_vacio():
            #carta = self.pop_carta()           # coger la carta de la cima
            carta = baraja.dar_carta()           # coger la carta de la cima
            jugadorAct = self.jugadores[i % (self.numJug+1)]  # calcular a quien repartir
            jugadorAct.anadir_carta(carta)           # anadir una carta al jugador actual
            i+=1




class Jugador(object):

    def __init__(self, jugador='Ordenador'):
        self.jugador = jugador

    def imprimir_nombre(self):
        print(self.jugador)

    def solicitar_carta_al_jugadorX(self,numCartas):
        idx = random.randint(0,numCartas-1)
        carta = self.mano.solicitar_carta(idx)
        return carta
        
    def eliminar_parejas(self):
        self.mano.eliminar_parejas()

    def eliminar_carta(self,carta):
        self.mano.eliminar_carta(carta)

    def tiene_cartas(self):
        return not self.mano.esta_vacio()

    def cuantas_cartas_quedan(self):
        return self.mano.cuantas_cartas_quedan()

    def anadir_carta(self,carta):
        self.mano.anadir_carta(carta)
        
class JugadorIA(Jugador):

    def __init__(self, jugador='Ordenador'):
        Jugador.__init__(self,"Ordenador")#invocamos al super
        self.mano = ManoIA()#anadimos la clase mano para almacenar la mano de la que dispone el jugador, ojo, hacer parejas (eliminar_cartas) es distinto en la mano persona y IA por eso hay dos


    def solicitar_a_que_jugador(self,idxJugActual,numJugadores):
        #seleccionar de manera random un jugador. Recordad que si en el random saliese el propio jugador, habria que volver a lanzar el random hasta que sea un jugador distinto del actual
        #############################
        #    TODO
        #############################
        #
        # Colocar aqui el codigo y descomentar
        #
        return jugSeleccionado



    def imprimir(self):
        print('la mano de: ')
        Jugador.imprimir_nombre(self)
        self.mano.imprimir()


class JugadorPersona(Jugador):
    
    def __init__(self,jugador='Persona'):
        Jugador.__init__(self,jugador)#invocamos al super
        self.mano = ManoPersona()#anadimos la clase mano para almacenar la mano de la que dispone el jugador
        
    def solicitar_a_que_jugador(self,idxJugActual,numJugadores):
        seguir = True
        print("\n")
        resp = int(input("Introduce su indice identificador"))
        if resp >=0 and resp <=numJugadores and resp != idxJugActual:
            seguir=False
            
        return resp

    def imprimir(self):
        print('la mano de: ')
        Jugador.imprimir_nombre(self)
        self.mano.imprimir()




if __name__ == "__main__":
    print('Ejecutando como programa principal')
    #Creando baraja y lista de jugadores

    seguirJugando = True# se seguira jugando mientras todos los jugadores tengan aun alguna carta TODO: Modificar condicion tal que se acabe el juego cuando solo quede un jugador con la carta complementaria a la mona
    baraja = Mazo()
    baraja.inicializar_baraja()
    jugadores = ListaJugadores()

    baraja.barajar()
    n_jugadores = int(input("Cuantos jugadores tiene el juego (sin contar las maquina)?"))
    print(n_jugadores)
    manos = jugadores.inicializar_partida(n_jugadores)

    jugadores.repartir_cartas(baraja)
    jugadores.jugar_primera_ronda()

    jugadores.inicializar_turno()
    while seguirJugando:
        seguirJugando,idxGanador = jugadores.jugar_ronda()
        jugadores.pasar_turno()
        
    print("Se ha acabado el juego y el jugador {0} has sido el ganador".format(idxGanador)) 

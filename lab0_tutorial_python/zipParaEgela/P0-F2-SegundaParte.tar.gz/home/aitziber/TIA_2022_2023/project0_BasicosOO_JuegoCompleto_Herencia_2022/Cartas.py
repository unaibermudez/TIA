import random
#from JuegoCartas import ListaJugadores, Jugador

class Carta(object):
    """Representa una carta en este caso de la baraja espanola
    
    Attributoss:
      palo: integer 0-3
      rango: integer 1-13
    """

    palo_nombres = ["Bastos", "Oros", "Copas", "Espadas"]
    rango_nombres = [None, "As", "2", "3", "4", "5", "6", "7", "Sota", "Caballo", "Rey"]

    def __init__(self, palo=0, rango=2):
        self.palo = palo
        self.rango = rango

    def __str__(self):
        """Devuelve la carta en modo legible."""
        return '%s de %s' % (Carta.rango_nombres[self.rango],
                             Carta.palo_nombres[self.palo])

    def __cmp__(self, otra):
        """Compara una carta con otra
        Devuelve un positivo si self > otra; negativo si otra > self;
        y 0 si equivalentes.
        """
        t1 = (self.palo, self.rango)
        t2 = (other.palo, other.rango)

        rdo = cmp(t1,t2)
        return rdo

    def __eq__(self, otra):
        rdo = NotImplemented
        if isinstance(otra, Carta):
            return self.rango == otra.rango and self.palo == otra.palo 
        return rdo

    def __ne__(self, otra):
        """self != otra"""
        eq = Carta.__eq__(self, otra)
        return not eq


class Mazo(object):
    """Representa el mazo de cartas.
    Attributos:
      cartas: una lista de cartas que anadimos una a una.
    """
    
    def __init__(self):
        self.cartas = []

        

    def __str__(self):
        res = []
        for carta in self.cartas:
            res.append(str(carta))
        return '\n'.join(res)

    def inicializar_baraja(self):
        for palo in range(4):
            for rango in range(1, 11):
                carta = Carta(palo, rango)
                self.cartas.append(carta)

    def solicitar_carta(self, idx):
          return self.cartas[idx]

    def anadir_carta(self, carta):
        """Anade una carta al mazo."""
        self.cartas.append(carta)

    def eliminar_carta(self, carta):
        """Elimina un acarta del mazo."""
        
        if carta in self.cartas:
            self.cartas.remove(carta)
            rdo = True
        else:
            rdo = False
        return rdo

    def esta_carta(self, carta):
        """Comprueba si una carta es mazo.
        True si esta
        False sino"""
        if carta in self.cartas:
            rdo = True
        else:
            rdo = False
        return rdo
    
    def pop_carta(self, i=-1):
        """Saca una carta del mazo.
        i: el indice de la carta a sacar (por defecto -1, es decir, la ultima); 
        """
        return self.cartas.pop(i)

    def barajar(self):
        """Baraja las cartas del mazo."""
        random.shuffle(self.cartas)

    def ordenarAsc(self):
        """Ordena las cartas del mazo en orden ascendente."""
        self.cartas.sort(key = lambda x: x.rango )
        #self.cartas.sort()
        

    def mover_cartas(self, mano, num):
        """Mueve un numero num de cartas desde el mazo a la mano.
        mano: objeto destino perteneciente a la clase Mano Hand objec
        num:  numero de cartas a desplazar
        """
        for i in range(num):
            mano.anadir_carta(self.pop_carta())

    def imprimir(self):
        for idx,carta in enumerate(self.cartas):
            print('  {0} - {1}'.format(idx,carta))

    def esta_vacio(self):
        return (len(self.cartas) == 0)

    def apartar_mona(self):
        return self.pop_carta()           # coger la carta de la cima y seleccionarla como mona eliminandola del mazo. Esto tiene como consecuencia que a quien le toque la complementaria de la mona, no podr� emparejarla y perder� la partida


    def dar_carta(self):
        return self.pop_carta()           # coger la carta de la cima

    def cuantas_cartas_quedan(self):
         return len(self.cartas)

    def eliminar_cartaIdx(self, idx):
        carta = self.cartas[idx]
        if carta in self.cartas:
            self.cartas.remove(carta)

        


class Mano(Mazo):
    """Representa una mano a jugar de un jugador."""
    
    def __init__(self):
        Mazo.__init__(self)

    
    def imprimir(self):
        toPrint = 'La mano del jugador '
        if Mazo.esta_vacio(self):
             toPrint +='esta vacia.'
             print(toPrint)
        else:
            toPrint +='contiene: '
            print(toPrint)
            Mazo.imprimir(self)


class ManoPersona(Mano):
    def __init__(self):
        Mano.__init__(self)


    def eliminar_parejas(self):

        cont = 0

        salir = False#chivato para salir cuando la pareja que se pretende eliminar no sea tal

        while not salir:
            Mano.imprimir(self)
            print("Si no existe posibilidad de generar una pareja introduce un -1, sino...")
            print("Que cartas forman pareja? Introduce dos valores de 0 a {0} separados por comas. Ejemplo 0,{1}".format(len(self.cartas)-1,len(self.cartas)-1))
            try:
                idxCarta,idxPareja = map(int, input().split(','))
                ###############################################
                #TODO
                ##############################################
                #
                # Completa el codigo
                # Comprobar que los indices existen sino mostrar el mensaje print("Te has equivocado, la pareja {0} {1} no es valida. Has perdido tu turno\n\n".format(carta,pareja))
                # Comprobar que la pareja es valida, es decir pareja.__eq__(posiblePareja)
                # Si las comprobaciones son correctas se procedera a eliminar las cartas que conforman la pareja

            except:
                print("Te has equivocado y no has introducido dos valores. Pasa el turno.\n\n")
                idxCarta,idxPareja = -1,-1
                salir = True
                
        return cont

class ManoIA(Mano):
    ####################################
    # Forman pareja:
    # numX de bastos y numX de espadas
    # numX de copas  y numx de oros
    ####################################
    def __init__(self):
        Mano.__init__(self)
        
    def eliminar_parejas(self):
        cont = 0
        originales_cartas = self.cartas[:]
        for carta in originales_cartas:
            pareja = Carta(3 - carta.palo, carta.rango)#
            #############################
            #TODO
            ############################
            #
            # Completar el codigo aqui
            # Si la pareja pertenece a las cartas de la mano
            # se obtiene la posicion (idx) de la pareja en, recordad que pareja es un objeto distinto al que hay en la lista de cartas por eso hay que obtener su idx para eliminar ese
            # una vez localizado se procede a eliminar tanto la pareja como la carta
            #
        return cont

    
        
def find_defining_class(obj, method_name):
    """Finds and returns the class object that will provide 
    the definition of method_name (as a string) if it is
    invoked on obj.
    obj: any python object
    method_name: string method name
    """
    for ty in type(obj).mro():
        if method_name in ty.__dict__:
            return ty
    return None


if __name__ == '__main__':
    #ejemplo1
    print("Ejemplo 1 mover cartas del mazo a una mano: ")
    mazo = Mazo()
    mazo.barajar()

    mano = Mano()
    print(find_defining_class(mano, 'barajar'))

    mazo.mover_cartas(mano, 5)
    mano.ordenarAsc()
    mano.imprimir()

    print("Ejemplo 2 repartir cartas entre 2 jugadores (7 cartas): ")
    mazo = Mazo()
    mano1 = ManoPersona('Aitzi')
    mano2 = ManoPersona('Koldo')
    mano3 =ManoPersona('Otro')
    mazo.repartir_cartas([mano1,mano2],7)
    mano1.imprimir()
    mano2.imprimir()
    mano3.imprimir()

    
    

    
